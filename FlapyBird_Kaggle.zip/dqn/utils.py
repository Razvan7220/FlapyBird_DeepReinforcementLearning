"""
Utility functions for DQN training.

Includes preprocessing, frame stacking, plotting, and reward shaping.
"""

import cv2
import numpy as np
import torch
import matplotlib.pyplot as plt
from collections import deque
import os


def shape_reward(reward, done, info=None, alive_bonus=0.2, death_penalty=-5.0):
    """
    Shape reward to provide denser learning signal.
    
    Args:
        reward: Original environment reward
        done: Whether episode terminated
        info: Environment info dict (optional, contains game state)
        alive_bonus: Reward for staying alive each step
        death_penalty: Penalty for dying (should be negative)
    
    Returns:
        Shaped reward value
    """
    shaped_reward = reward
    
    # 1. Strong penalty for death (vs default -1)
    if done and reward < 0:
        shaped_reward = death_penalty
    
    # 2. Small reward for surviving each frame
    # Encourages agent to learn survival before optimization
    if not done:
        shaped_reward += alive_bonus
    
    # 3. Optional: Use info dict for additional shaping
    # (Flappy Bird gym might not provide detailed info, but we try)
    if info is not None and isinstance(info, dict):
        # Reward being centered between pipes (if available)
        if 'player_y' in info and 'next_pipe_top_y' in info and 'next_pipe_bottom_y' in info:
            pipe_center = (info['next_pipe_top_y'] + info['next_pipe_bottom_y']) / 2
            player_y = info['player_y']
            distance_to_center = abs(player_y - pipe_center)
            
            # Reward being close to pipe center (sigmoid-like bonus)
            centering_bonus = 0.5 / (1.0 + distance_to_center / 50.0)
            shaped_reward += centering_bonus
    
    return shaped_reward


class FramePreprocessor:
    """
    Preprocesses frames from the environment for neural network input.
    
    Typical preprocessing pipeline:
    1. Convert to grayscale (reduce channels from 3 to 1)
    2. Resize to smaller resolution (84x84 for efficiency)
    3. Normalize pixel values to [0, 1]
    4. Stack multiple frames for temporal information
    """
    
    def __init__(self, width=84, height=84, grayscale=True, normalize=True):
        """
        Args:
            width: int - target width
            height: int - target height
            grayscale: bool - convert to grayscale
            normalize: bool - normalize to [0, 1]
        """
        self.width = width
        self.height = height
        self.grayscale = grayscale
        self.normalize = normalize
    
    def process(self, frame):
        """
        Process a single frame.
        
        Args:
            frame: np.ndarray - raw frame from environment (H, W, C)
            
        Returns:
            np.ndarray - processed frame (H, W) or (H, W, 1)
        """
        # Convert to grayscale if needed
        if self.grayscale and len(frame.shape) == 3:
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        
        # Resize
        frame = cv2.resize(frame, (self.width, self.height), 
                          interpolation=cv2.INTER_AREA)
        
        # Normalize
        if self.normalize:
            frame = frame.astype(np.float32) / 255.0
        
        return frame


class FrameStack:
    """
    Stacks multiple frames to capture temporal information.
    
    Useful for understanding velocity and direction of movement.
    """
    
    def __init__(self, num_frames=4):
        """
        Args:
            num_frames: int - number of frames to stack
        """
        self.num_frames = num_frames
        self.frames = deque(maxlen=num_frames)
    
    def reset(self, frame):
        """Reset with initial frame (repeat it num_frames times)."""
        for _ in range(self.num_frames):
            self.frames.append(frame)
        return self.get_state()
    
    def push(self, frame):
        """Add new frame and return stacked state."""
        self.frames.append(frame)
        return self.get_state()
    
    def get_state(self):
        """Return current stacked state as numpy array."""
        # Stack along first dimension: (num_frames, H, W)
        return np.stack(self.frames, axis=0)


class EpsilonScheduler:
    """
    Manages epsilon decay for epsilon-greedy exploration.
    
    Supports linear and exponential decay.
    """
    
    def __init__(self, start=1.0, end=0.01, decay_steps=100000, decay_type='linear'):
        """
        Args:
            start: float - initial epsilon
            end: float - final epsilon
            decay_steps: int - steps to decay from start to end
            decay_type: str - 'linear' or 'exponential'
        """
        self.start = start
        self.end = end
        self.decay_steps = decay_steps
        self.decay_type = decay_type
        self.current_step = 0
    
    def get_epsilon(self):
        """Get current epsilon value."""
        if self.current_step >= self.decay_steps:
            return self.end
        
        if self.decay_type == 'linear':
            epsilon = self.start - (self.start - self.end) * (self.current_step / self.decay_steps)
        else:  # exponential
            epsilon = self.end + (self.start - self.end) * np.exp(-self.current_step / self.decay_steps)
        
        return epsilon
    
    def step(self):
        """Increment step counter."""
        self.current_step += 1


def plot_training_curves(rewards, losses, epsilons, save_path=None):
    """
    Plot training curves: rewards, losses, and epsilon over time.
    
    Args:
        rewards: list - episode rewards
        losses: list - training losses
        epsilons: list - epsilon values
        save_path: str - path to save figure (optional)
    """
    fig, axes = plt.subplots(3, 1, figsize=(12, 10))
    
    # Rewards
    axes[0].plot(rewards, alpha=0.3, color='blue', label='Episode Reward')
    if len(rewards) > 50:
        # Moving average
        window = 50
        moving_avg = np.convolve(rewards, np.ones(window)/window, mode='valid')
        axes[0].plot(range(window-1, len(rewards)), moving_avg, 
                    color='red', linewidth=2, label=f'{window}-Episode Moving Average')
    axes[0].set_xlabel('Episode')
    axes[0].set_ylabel('Reward')
    axes[0].set_title('Training Rewards')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    # Losses
    axes[1].plot(losses, alpha=0.6, color='green')
    axes[1].set_xlabel('Training Step')
    axes[1].set_ylabel('Loss')
    axes[1].set_title('Training Loss')
    axes[1].grid(True, alpha=0.3)
    
    # Epsilon
    axes[2].plot(epsilons, color='purple')
    axes[2].set_xlabel('Step')
    axes[2].set_ylabel('Epsilon')
    axes[2].set_title('Exploration Rate (Epsilon)')
    axes[2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"📊 Plot saved to {save_path}")
    else:
        plt.show()
    
    plt.close()


def save_checkpoint(agent, episode, rewards, losses, path):
    """
    Save training checkpoint.
    
    Args:
        agent: DQNAgent - agent to save
        episode: int - current episode
        rewards: list - episode rewards
        losses: list - training losses
        path: str - save path
    """
    checkpoint = {
        'episode': episode,
        'q_network_state_dict': agent.q_network.state_dict(),
        'target_network_state_dict': agent.target_network.state_dict(),
        'optimizer_state_dict': agent.optimizer.state_dict(),
        'rewards': rewards,
        'losses': losses,
        'epsilon': agent.epsilon_scheduler.get_epsilon()
    }
    
    torch.save(checkpoint, path)
    print(f"💾 Checkpoint saved: {path}")


def load_checkpoint(agent, path):
    """
    Load training checkpoint.
    
    Args:
        agent: DQNAgent - agent to load into
        path: str - checkpoint path
        
    Returns:
        dict - checkpoint data (episode, rewards, losses)
    """
    checkpoint = torch.load(path)
    
    agent.q_network.load_state_dict(checkpoint['q_network_state_dict'])
    agent.target_network.load_state_dict(checkpoint['target_network_state_dict'])
    agent.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    
    print(f"✅ Checkpoint loaded from: {path}")
    
    return {
        'episode': checkpoint['episode'],
        'rewards': checkpoint['rewards'],
        'losses': checkpoint['losses'],
        'epsilon': checkpoint['epsilon']
    }


class RewardShaper:
    """
    Optional reward shaping to improve learning.
    
    Can add rewards for survival, penalize deaths, etc.
    """
    
    def __init__(self, alive_bonus=0.1, death_penalty=-1.0, scale=1.0):
        self.alive_bonus = alive_bonus
        self.death_penalty = death_penalty
        self.scale = scale
    
    def shape(self, reward, done, info=None):
        """
        Shape reward based on game state.
        
        Args:
            reward: float - original reward
            done: bool - episode terminated
            info: dict - additional info from environment
            
        Returns:
            float - shaped reward
        """
        shaped = reward * self.scale
        
        # Add small bonus for staying alive
        if not done:
            shaped += self.alive_bonus
        else:
            shaped += self.death_penalty
        
        return shaped


def calculate_statistics(rewards):
    """
    Calculate statistics from list of rewards.
    
    Returns:
        dict - mean, std, min, max, median
    """
    rewards = np.array(rewards)
    return {
        'mean': np.mean(rewards),
        'std': np.std(rewards),
        'min': np.min(rewards),
        'max': np.max(rewards),
        'median': np.median(rewards)
    }


def print_training_stats(episode, total_episodes, reward, epsilon, loss, 
                        avg_reward_100, steps, total_steps):
    """
    Print formatted training statistics.
    """
    print(f"━" * 80)
    print(f"📊 Episode {episode}/{total_episodes}")
    print(f"   Reward: {reward:.2f} | Avg(100): {avg_reward_100:.2f}")
    print(f"   Epsilon: {epsilon:.4f} | Loss: {loss:.4f}")
    print(f"   Steps: {steps} | Total: {total_steps:,}")
    print(f"━" * 80)


if __name__ == "__main__":
    # Test preprocessing
    print("Testing FramePreprocessor...")
    preprocessor = FramePreprocessor(84, 84)
    
    # Fake frame
    frame = np.random.randint(0, 256, (288, 512, 3), dtype=np.uint8)
    processed = preprocessor.process(frame)
    print(f"Original shape: {frame.shape}")
    print(f"Processed shape: {processed.shape}")
    print(f"Value range: [{processed.min():.2f}, {processed.max():.2f}]")
    
    # Test frame stacking
    print("\nTesting FrameStack...")
    stack = FrameStack(4)
    state = stack.reset(processed)
    print(f"Stacked state shape: {state.shape}")
    
    # Test epsilon scheduler
    print("\nTesting EpsilonScheduler...")
    scheduler = EpsilonScheduler(1.0, 0.01, 1000)
    epsilons = [scheduler.get_epsilon() for _ in range(1000)]
    for _ in range(1000):
        scheduler.step()
    print(f"Initial epsilon: {epsilons[0]:.4f}")
    print(f"Final epsilon: {epsilons[-1]:.4f}")
